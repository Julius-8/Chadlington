# Reupload

Original upload (link)[https://www.nexusmods.com/valheim/mods/1054] - uploaded/created by nexusmods user (KillingGodVH)[https://www.nexusmods.com/valheim/users/110902883].

----

Mod changes ladder's behavior, so player can go up smoothly without need to auto-jump

For install:

For install unpack .rar into your: "Valheim/BeplnEx" folder.

Video:
https://youtu.be/upnbvBai3bI

Usage: just walk/run on ladder, you will notice the difference