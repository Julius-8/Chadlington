Just zoom all the way in to go into first person mode.

Please report bugs or other discussions on the nexus page,
https://www.nexusmods.com/valheim/mods/44

needs https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/


Some info about this mod:

The goal of this mod is to incorporate a first person view, while still retaining as much of the original feel as possible.
I think the feel of the game is great as is I just want to bring that to a first person view without changing the vision of the game.


I've added a configuration file for FOV and a couple other things. It is generated first time you run the game with the mod loaded, example at bottom of page. (located in "...Valheim\BepInEx\config\CameraMod.Kailen_.cfg"


Installation: after installing BepInexPack just put the CameraMod.dll in the plugins folder (in its own nested folder if you want)
...steamapps\common\Valheim\BepInEx\plugins\


These settings are reloaded anytime you hit the OK button on the in game settings. So you can experiment with the FOV and other settings while in game.
