DisableEnvironmentParticles
Created by aedenthorn on Nexus Mods. Uploaded to Thunderstore for the people. Will be deleted on request or when the author uploads it to thunderstore.