# HelmetBeGone

Successor to my InvisHelm-REmake which contains some bug fixes for armorstand/itemstand and dverger helmet issues. May probably work in co-op/multiplayer mode but not sure. Dont have a way to test it.

If you found any issues you can always ping me at any discord channel. Im everywhere XD or you could just visit my mod at nexus and post a comment there.

## Installation (manual)

copy `plugins` folder to your `BepInEx` folder

## Changelog

<br/>
v1.0.3<br/>
- removed version check<br/>
- helmet is now always hidden at the start just like the original invishelm but you can still press the hotkey to show and hide the helmet.<br/>
<br/>
v1.0.2<br/>
- optimized code<br/>
<br/>
v1.0.1<br/>
- added version checks<br/>
- updated to latest valheim assemblies<br/>
<br/>
v1.0.0<br/>
- first release

